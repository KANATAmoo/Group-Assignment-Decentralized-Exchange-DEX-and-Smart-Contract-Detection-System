from flask import Flask, request, jsonify
from flask_cors import CORS
import os
import subprocess

app = Flask(__name__)
CORS(app)  # Allow cross-domain requests
@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.json
    contract_code = data.get('code', None)

    if contract_code is None:
        return jsonify({'error': 'No contract code provided'}), 400

    # Write the smart contract code into the .sol file
    file_path = 'contract.sol'
    with open(file_path, 'w') as f:
        f.write(contract_code)

    # Use Slither for analysis
    try:
        result = subprocess.run(
            ['slither', file_path, '--json', 'results.json'],
            capture_output=True,
            text=True,
            check=True
        )

        with open('results.json', 'r') as f:
            analysis_results = f.read()

        return jsonify({'analysis': analysis_results})
    except subprocess.CalledProcessError as e:
        return jsonify({'error': e.stderr}), 500

if __name__ == '__main__':
    app.run(debug=True,port=5000)






import os
from flask import Flask, request, jsonify
from flask_cors import CORS  # 允许跨域请求
from openai import OpenAI

app = Flask(__name__)
CORS(app)  # 启用跨域请求支持

# 配置阿里云通义千问客户端
client = OpenAI(
    api_key=os.getenv("DASHSCOPE_API_KEY"),  # 从环境变量读取 API 密钥
    base_url="https://dashscope.aliyuncs.com/compatible-mode/v1"
)


@app.route('/analyze_contract', methods=['POST'])
def analyze_contract():
    # 从请求体中获取智能合约代码
    data = request.json
    contract_code = data.get('code')

    if not contract_code:
        return jsonify({'error': 'No contract code provided'}), 400

    try:
        # Call the Tongyi Qianwen API for analysis
        response = client.chat.completions.create(
            model="qwen-turbo",  # Use the appropriate model
            messages=[{
                'role': 'system',
                'content': 'You are a helpful assistant that analyzes smart contracts for vulnerabilities.'
            }, {
                'role': 'user',
                'content': f'Please analyze this smart contract: {contract_code}'
            }]
        )
        # 打印响应查看数据结构
        print(response)  # 打印响应对象，查看其内容

        # 提取分析内容
        analysis_content = response.choices[0].message.content if response.choices else "No analysis content found."

        # 将分析结果返回给前端
        return jsonify({'analysis': analysis_content})

    except Exception as e:
        # 捕获并返回任何错误信息
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5001)






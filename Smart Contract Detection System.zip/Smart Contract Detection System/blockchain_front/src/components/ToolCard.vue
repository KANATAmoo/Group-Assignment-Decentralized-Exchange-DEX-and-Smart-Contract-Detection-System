<script setup>
import { defineProps } from 'vue';

const props = defineProps({
  icon: String,
  title: String
});
</script>

<template>
<div class="tool-card">
    <img :src="icon" alt="Tool Icon" />
    <p>{{ title }}</p>
  </div>
</template>

<style scoped>

</style>
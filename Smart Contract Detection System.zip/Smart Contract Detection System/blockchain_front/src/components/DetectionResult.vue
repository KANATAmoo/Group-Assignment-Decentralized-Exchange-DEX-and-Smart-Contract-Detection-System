<script setup>
import { defineProps } from 'vue';

const props = defineProps({
  results: Array
});
</script>

<template>
  <div class="detection-result">
    <h3>Detection Results</h3>
    <ul>
      <li v-for="(result, index) in results" :key="index" :class="result.type">
        <span>{{ result.line }}:</span> <span>{{ result.type }}:</span> {{ result.message }}
      </li>
    </ul>
  </div>
</template>

<style scoped>

</style>
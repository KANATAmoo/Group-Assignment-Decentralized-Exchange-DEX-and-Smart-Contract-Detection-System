<script setup>
import { ref, defineEmits } from 'vue';

const code = ref('');
const emit = defineEmits(['analyze']);
const analyze = () => {
  emit('analyze', code.value);
};
</script>

<template>
  <div class="code-editor">
    <textarea v-model="code" placeholder="Paste your smart contract here..." />
    <button @click="analyze">检测智能合约</button>
  </div>
</template>

<style scoped>

</style>